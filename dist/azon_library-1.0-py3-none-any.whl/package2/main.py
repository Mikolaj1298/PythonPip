def say_hello():
    return "Something else from package2"
