import requests
import json
import time
from . import bibtex_classes
from requests.exceptions import HTTPError

class Manager:
    def test(self):
        return "It actually works"
